<li class="lao-font model-item"><a><i class="fa fa-edit"></i> ຈັດການຂໍ້ມູນ <span class="fa fa-chevron-down"></span></a>
    <ul class="nav child_menu">
        <li class="model-item"><a href="{{ route('products') }}">ຊື່ສິນຄ້າ</a></li>
        <li class="model-item"><a href="{{ route('product-category') }}">ປະເພດສິນຄ້າ [ph4]</a></li>
        <li class="model-item"><a href="{{ route('product-brand') }}">ຍີ່ຫໍ່ສິນຄ້າ [ph5]</a></li>
        <li class="model-item"><a href="{{ route('product-pattern') }}">ຮູບແບບສິນຄ້າ [ph6]</a></li>
        <li class="model-item"><a href="{{ route('product-size') }}">ຂະໜາດສິນຄ້າ [ph7]</a></li>
        <li class="model-item"><a href="{{ route('product-design') }}">ອອກແບບ [ph8]</a></li>
        <li class="model-item"><a href="{{ route('group-warehouse') }}">ສາງ</a></li>
        {{-- <li class="model-item"><a href="{{ route('pro-type.index') }}">ປະເພດສິນຄ້າ</a></li> --}}
    </ul>
</li>
