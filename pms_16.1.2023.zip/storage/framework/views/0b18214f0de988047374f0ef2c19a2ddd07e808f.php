<li class="model-item"><a href="/"><i class="fa fa-product-hunt" aria-hidden="true"></i>
        ສິນຄ້າໃໝ່ພ້ອມຜຸກບັນຊີ</a>
</li>




<?php /**PATH D:\xampp\htdocs\pms\resources\views/layouts/accountanter-sidebar.blade.php ENDPATH**/ ?>