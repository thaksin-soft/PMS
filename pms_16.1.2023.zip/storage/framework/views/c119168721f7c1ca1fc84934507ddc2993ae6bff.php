<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="bg-white border-b border-gray-200 mt-3 lao-font py-8">
                    <h4 class="text-info"><i class="fa fa-pied-piper" aria-hidden="true"></i> ປະເພດສິນຄ້າ</h4>

                    <div class="row">
                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('pro-type.store')); ?>">
                                <?php echo csrf_field(); ?>

                                <!-- full Name -->
                                <div>
                                    <label for="prt_code"><span class="text-danger">*</span> Code</label>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'prt_code','class' => 'form-control','type' => 'text','name' => 'prt_code','value' => old('prt_code'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'prt_code','class' => 'form-control','type' => 'text','name' => 'prt_code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('prt_code')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>

                                <!-- full Name -->
                                <div class="mt-4">
                                    <label for="prt_name"><span class="text-danger">*</span> ຊື່ປະເພດສິນຄ້າ</label>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'prt_name','class' => 'form-control','type' => 'text','name' => 'prt_name','value' => old('prt_name'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'prt_name','class' => 'form-control','type' => 'text','name' => 'prt_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('prt_name')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>

                                <div class="flex items-center justify-end mt-4">


                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn btn-success']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-success']); ?><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                        <?php echo e(__(' ບັນທຶກ')); ?>

                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-8">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ລຳດັບ</th>
                                        <th>Code</th>
                                        <th>ຊື່ປະເພດສິນຄ້າ</th>
                                        <th width="30">ແກ້ໄຂ</th>
                                        <th width="30">ລຶບ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(($key + 1)); ?></td>
                                        <td><?php echo e($item->code); ?></td>
                                        <td><?php echo e($item->prt_name); ?></td>
                                        <td class="text-center">
                                            <a href="#" class="text-warning" data-toggle="modal"
                                                data-target="#modal-edit-emp"
                                                onclick="set_edit_prt(<?php echo e($item->id); ?>, '<?php echo e($item->code); ?>', '<?php echo e($item->prt_name); ?>')"><i
                                                    class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="text-danger"
                                                onclick="delete_product_type(<?php echo e($item->id); ?>)"><i class="fa fa-trash"
                                                    aria-hidden="true"></i></a>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="modal-edit-emp">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header lao-font">
                    <h4 class="modal-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> ແກ້ໄຂຂໍ້ມູນ</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body lao-font">
                    <form method="POST" action="" id="form-edit-prt">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="prt_id">
                        <!-- full Name -->
                        <div>
                            <label for="edit_code"><span class="text-danger">*</span> Code</label>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['class' => 'form-control','type' => 'text','name' => 'edit_code','value' => old('edit_code'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','type' => 'text','name' => 'edit_code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('edit_code')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>

                        <div class="mt-4">
                            <label for="edit_prt_name"><span class="text-danger">*</span> ຊື່ຍີ່ຫໍ້ສິນຄ້າ</label>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['class' => 'form-control','type' => 'text','name' => 'edit_prt_name','value' => old('edit_prt_name'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','type' => 'text','name' => 'edit_prt_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('edit_prt_name')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>


                        <div class="flex items-center justify-end mt-4">


                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn btn-success']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-success']); ?><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                <?php echo e(__(' ບັນທຶກ')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" id="close-edit">Close</button>
                </div>

            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<script>
$(document).ready(function(e) {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#form-edit-prt').submit(function(e) {
        e.preventDefault();
        $('#close-edit').click();
        var id = $('#form-edit-prt input[name="prt_id"]').val();
        var url = "pro-type/" + id;
        $.blockUI({
            message: 'ກຳລັງແກ້ໄຂ'
        });
        $.ajax({
            url: url,
            type: 'PUT',
            data: $(this).serialize(),
            success: function(e) {
                $.unblockUI();
                console.log(e);
                if (e == 'success') {
                    location.reload();
                }
            }
        });
    });
});

function set_edit_prt(id, code, brand_name) {
    $('#form-edit-prt input[name="prt_id"]').val(id);
    $('#form-edit-prt input[name="edit_code"]').val(code);
    $('#form-edit-prt input[name="edit_prt_name"]').val(brand_name);
}

function delete_product_type(id) {
    Swal.fire({
        title: '<span class="lao-font">ຢືນຢັນການລຶບຂໍ້ມູນ </span>?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: '<span class="lao-font">ຢືນຢັນ</span>'
    }).then((result) => {
        var url = 'pro-type/' + id;
        var token = $("meta[name='csrf-token']").attr("content");
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                data: {
                    _token: token,
                    id: id
                },
                success: function(e) {
                    console.log(e);
                    if (e == 'success') {
                        location.reload();
                    }
                }
            })
        }
    })
}
</script><?php /**PATH C:\xampp\htdocs\track-online\resources\views/product-type/index.blade.php ENDPATH**/ ?>