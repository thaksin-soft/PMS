<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4 class="text-info"><i class="fa fa-shopping-cart" aria-hidden="true"></i> ລູກຄ້າຊື້ສິນຄ້າ
                        </h4>
                        <form action="" method="POST" id="form-customer-purchased">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="txt_track_id" value="<?php echo e($t_id); ?>">

                            <div class="row mb-4">
                                <div class="col-md-12">
                                    <h5 class="text-drak"><i class="fa fa-user" aria-hidden="true"></i> ລູກຄ້າ
                                    </h5>

                                    <div class="row">
                                        <div class="col-md-3">
                                            <label for="">ລະຫັດ</label>
                                            <input type="text" class="form-control" value="<?php echo e($t_code); ?>"
                                                readonly name="txt_track_code"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ຊື່ລູກຄ້າ</label>
                                            <input type="text" class="form-control" value="<?php echo e($data->tr_name); ?>"
                                                readonly name="txt_cus_name"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ທີ່ຢູ່</label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($data->tr_cus_address); ?>" readonly
                                                name="txt_cus_address"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ເບິໂທ</label>
                                            <input type="text" class="form-control" value="<?php echo e($data->tr_tel); ?>"
                                                readonly name="txt_cus_tel"><br>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <hr>
                            <div class="row mb-4">

                                <div class="col-md-12">
                                    <h5 class="text-drak"><i class="fa fa-product-hunt" aria-hidden="true"></i>
                                        ລາຍການສິນຄ້າ
                                    </h5>
                                    <table class="table">
                                        <tr>
                                            <th>ລາຍການ</th>
                                            <th>ກຸ່ມສິນຄ້າ</th>
                                            <th>ໝວດສິນຄ້າ</th>
                                            <th>ຍີ່ຫໍ້</th>
                                            <th width="10%">ຂະໜາດ</th>
                                        </tr>
                                        <tbody id="product-table">
                                            <?php
                                                $all_qty_product = count($con_cus_product) - 1;
                                            ?>
                                            <?php $__currentLoopData = $con_cus_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><input type="hidden" class="form-control"
                                                            value="<?php echo e($product_item->product_purchased); ?>"
                                                            name="txt_product_purchased[]" readonly>
                                                        <?php echo e($product_item->product_purchased); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($g_item->id == $product_item->prg_id): ?>
                                                                <input type="hidden" value="<?php echo e($g_item->id); ?>"
                                                                    name="cb_pro_group[]">
                                                                <?php echo e($g_item->prg_name); ?>

                                                            <?php endif; ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </td>
                                                    <td>
                                                        <?php
                                                        $pg_id = $product_item->prg_id;
                                                        $cate = App\Models\ProductCategory::where('pg_id', $pg_id)->get();
                                                        ?>

                                                        <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prc_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <?php if($prc_item->id == $product_item->prc_id): ?>
                                                                <?php echo e($prc_item->prc_name); ?>

                                                                <input type="hidden" name="cb_pro_cate[]"
                                                                    value="<?php echo e($prc_item->id); ?>">

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($b_item->id == $product_item->prb_id): ?>
                                                                <?php echo e($b_item->brand_name); ?>

                                                                <input type="hidden" name="cb_brand[]"
                                                                    value="<?php echo e($b_item->id); ?>">
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <input type="hidden" class="form-control" name="txt_size[]"
                                                            placeholder="..."
                                                            value="<?php echo e($product_item->product_size); ?>" required
                                                            readonly>
                                                        <?php echo e($product_item->product_size); ?>

                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="text-drak"><i class="fa fa-user" aria-hidden="true"></i>
                                        ຂໍ້ມູນການຂາຍ
                                    </h5>
                                    <label for="">ເລກບິນ</label>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="txt_bill_id" required>
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button"><i class="fa fa-search"
                                                    aria-hidden="true"></i></button>
                                        </div>
                                    </div>
                                    <label for="">ວັນທີ່ຂາຍ</label>
                                    <input type="date" class="form-control" name="txt_date_sale"
                                        value="<?php echo e(date('Y-m-d')); ?>">
                                </div>
                                <div class="col-md-12" style="padding-right: 12%; padding-left: 10%">
                                    <hr>


                                    <button class="btn btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                        ບັນທຶກການຊື້</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#form-customer-purchased').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: '<span class="lao-font">ຢືນຢັນ</span> ?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.blockUI({
                        message: ''
                    });
                    $.ajax({
                        url: "<?php echo e(route('save-customer-purchased')); ?>",
                        type: "POST",
                        data: $(this).serialize(),
                        success: function(e) {
                            $.unblockUI();
                            console.log(e);
                            if (e == 'success') {
                                window.location.href =
                                    "<?php echo e(route('seller-track-show')); ?>";
                            }
                        }
                    });
                }
            })
        })

    });

    function load_product_category(id) {
        $.blockUI({
            message: ''
        });
        $.ajax({
            url: "<?php echo e(route('sell-load-product-category')); ?>",
            type: "POST",
            data: {
                'id': id
            },
            success: function(result) {
                $('#cb_pro_cate').html('');
                $.each(result, function(index, item) {
                    $('#cb_pro_cate').append('<option value="' + item.id + '">' + item.prc_name +
                        '</option>');
                });
                $.unblockUI();
            }
        });
    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/sellers/customer-purchase.blade.php ENDPATH**/ ?>