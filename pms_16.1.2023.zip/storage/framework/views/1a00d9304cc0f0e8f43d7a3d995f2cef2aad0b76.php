<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4 class="text-info"><i class="fa fa-info-circle" aria-hidden="true"></i> ຂໍ້ມູນຕິດຕໍ່ລູກຄ້າ
                        </h4>
                        <div class="row">
                            
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    
                                    $tr_name = $item->tr_name;
                                    $tr_tel = $item->tr_tel;
                                    $tr_date = $item->created_at;
                                    $address = $item->tr_cus_address;
                                    
                                    //ດຶງຂໍ້ມູນມາຈາກການຕິດຕໍ່ຫາລູກຄ້າ
                                    $con_cus = App\Models\ContractCustomer::where('tr_code', $item->tr_code)
                                        ->where('status', '!=', 'ກຳລັງຕິດຕໍ່')
                                        ->select('crm_contract_customer.*')
                                        ->orderBy('id', 'desc')
                                        ->first();
                                ?>

                                <div class="col-md-6 mb-3">
                                    <div class="seller-track-info p-2">
                                        <p class="text-center text-danger"><?php echo e($tr_date); ?></p>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <h6><b>ຊື່ລູກຄ້າ:</b> <span
                                                        class="text-primary"><?php echo e($tr_name); ?></span>
                                                </h6>
                                            </div>
                                            <div class="col-sm-6">
                                                <h6><b>ເບິໂທ:</b> <span class="text-primary"><?php echo e($tr_tel); ?></span>
                                                </h6>
                                            </div>
                                        </div>
                                        <h6><b>ທີ່ຢູ່:</b> <span class="text-primary"><?php echo e($address); ?></span>
                                        </h6>
                                        
                                        <?php if($con_cus): ?>
                                            <?php
                                                $con_status = $con_cus->status;
                                                //ດຶງຂໍ້ມູນສິນຄ້າຈາກການສອບຖາມລູກຄ້າ
                                                $con_product = App\Models\ProductCustomerContract::join('crm_brands', 'crm_brands.id', 'crm_product_cus_contract.prb_id')
                                                    ->where('tr_code', $item->tr_code)
                                                    ->select('crm_product_cus_contract.*', 'crm_brands.brand_name')
                                                    ->get();
                                                $cc_id = $con_product[0]->cc_id;
                                            ?>
                                            <table class="table">
                                                <?php $__currentLoopData = $con_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con_p_key => $con_pro_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="50"><?php echo e($con_p_key + 1); ?></td>
                                                        <td><?php echo e($con_pro_item->product_purchased); ?></td>
                                                        <td><?php echo e($con_pro_item->pr_size); ?></td>
                                                        <td><?php echo e($con_pro_item->brand_name); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        <?php else: ?>
                                            
                                            <?php
                                                //ດຶງຂໍ້ມູນສິນຄ້າຈາກການຕິດຕໍ່ຂອງລູກຄ້າ
                                                $interest_pro = App\Models\ProductCustomerInterest::join('crm_brands', 'crm_brands.id', 'crm_product_cus_interest.prb_id')
                                                    ->where('crm_product_cus_interest.tr_code', $item->tr_code)
                                                    ->select('crm_product_cus_interest.*', 'crm_brands.brand_name')
                                                    ->get();
                                            ?>
                                            <table class="table">
                                                <?php $__currentLoopData = $interest_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest_p_key => $interest_pro_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="50">
                                                            <?php echo e($interest_p_key + 1); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($interest_pro_item->cus_interest_product); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($interest_pro_item->pr_size); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($interest_pro_item->brand_name); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        <?php endif; ?>

                                        <hr>
                                        
                                        <?php if($item->status == 'ລໍຖ້າຕິດຕໍ່'): ?>
                                            
                                            <form action="<?php echo e(route('contract-customer')); ?>" method="GET"
                                                id="form-con-cus-<?php echo e($item->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="track_id" value="<?php echo e($item->id); ?>">
                                                <input type="hidden" name="track_code" value="<?php echo e($item->tr_code); ?>">

                                                


                                                <button class="btn btn-sm btn-danger" type="button"
                                                    id="btn-con-cus-<?php echo e($item->id); ?>"><i
                                                        class="fa fa-volume-control-phone" aria-hidden="true"></i>
                                                    ຢືນຢັນຕິດຕໍ່ຫາລູກຄ້າ</button>
                                            </form>
                                            <script>
                                                $(document).ready(function(e) {
                                                    $('button#btn-con-cus-' + <?php echo e($item->id); ?>).click(function(e) {
                                                        let $form = $('#form-con-cus-' + <?php echo e($item->id); ?>).closest('form');
                                                        Swal.fire({
                                                            title: '<span class="lao-font">ຢືນຢັນການຕິດຕໍ່</span> ?',
                                                            html: '<span class="lao-font">ຖ້າຢືນຢັນ ຈະບັນທືກຂໍ້ມູນການຕິດຕໍ່ລູກຄ້າ ອັດຕະໂນມັດ !!!</span>',
                                                            icon: 'warning',
                                                            showCancelButton: true,
                                                            confirmButtonColor: '#3085d6',
                                                            cancelButtonColor: '#d33',
                                                            confirmButtonText: '<span class="lao-font">ຢືນຢັນ</span>'
                                                        }).then((result) => {
                                                            if (result.isConfirmed) {
                                                                $form.submit();
                                                            }
                                                        });
                                                    })
                                                })
                                            </script>
                                        <?php else: ?>
                                            

                                            <?php if($con_status == 'ຊື້'): ?>
                                                <form action="<?php echo e(route('customer-purchase')); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="track_id" value="<?php echo e($item->id); ?>">
                                                    <input type="hidden" name="track_code"
                                                        value="<?php echo e($item->tr_code); ?>">
                                                    <button class="btn btn-sm btn-primary"><i class="fa fa-money"
                                                            aria-hidden="true"></i>
                                                        ລູກຄ້າຊື້ສິນຄ້າ</button>
                                                </form>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('call-check-back')); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="cc_id" value="<?php echo e($cc_id); ?>">
                                                    <input type="hidden" name="track_id" value="<?php echo e($item->id); ?>">
                                                    <input type="hidden" name="track_code"
                                                        value="<?php echo e($item->tr_code); ?>">
                                                    <button class="btn btn-sm btn-warning"><i
                                                            class="fa fa-volume-control-phone" aria-hidden="true"></i>
                                                        ຕິດຕໍ່ຫາລູກຄ້າຄືນ</button>
                                                </form>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    function validate(form) {
        if (!form) {
            alert('Please correct the errors in the form!');
            return false;
        } else {
            return confirm('Do you really want to submit the form?');
            /*  */
        }

    }
</script>
<?php /**PATH C:\xampp\htdocs\crm\resources\views/sellers/track-info.blade.php ENDPATH**/ ?>