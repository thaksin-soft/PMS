<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <ul class="nav side-menu">
            <li class="model-item"><a href="/"><i class="fa fa-home"></i> Dashboard</a></li>

            <li class="lao-font model-item"><a><i class="fa fa-edit"></i> ຈັດການຂໍ້ມູນ <span
                        class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    <li class="model-item"><a href="<?php echo e(route('product-brand')); ?>">ຍີ່ຫໍ່ສິນຄ້າ [ph5]</a></li>
                    <li class="model-item"><a href="<?php echo e(route('product-pattern')); ?>">ຮູບແບບສິນຄ້າ [ph6]</a></li>
                    <li class="model-item"><a href="<?php echo e(route('product-size')); ?>">ຂະໜາດສິນຄ້າ [ph7]</a></li>
                    <li class="model-item"><a href="<?php echo e(route('product-design')); ?>">ອອກແບບ [ph8]</a></li>
                    
                </ul>
            </li>

            

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layouts/admin-sidebar.blade.php ENDPATH**/ ?>