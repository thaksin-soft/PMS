<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4><i class="fa fa-info-circle" aria-hidden="true"></i> ລາຍລະອຽດຂອງສິນຄ້າ</h4>
                        <hr>

                        <div class="row">
                            <div class="col-sm-8" style="border-right: 1px solid">
                                <h5 class="text-primary"><b>ຂໍ້ມູນສິນຄ້າ</b></h5>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label for="ph7"><b>ຊື່ສິນຄ້າ</b></label>

                                    </div>

                                    <div class="col-sm-3">
                                        <label for="item_type"><b>ກຸ່ມສິນຄ້າ</b></label>

                                    </div>
                                    <div class="col-sm-3">
                                        <label for="unit_type"><b>ປະເພດໜ່ວຍນັບ</b></label>

                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label for="cost_type"><b>ປະເພດຕົ້ນທຶນ</b></label>

                                    </div>

                                    <div class="col-sm-3">
                                        <label for="unit_cost"><b>ຫົວໜ່ວຍຕົ້ນທຶນ</b></label>

                                    </div>


                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="ph1"><b>ໝວດສິນຄ້າຫຼັກ (PH1)</b></label>

                                    </div>

                                    <div class="col-sm-4">
                                        <label for="ph2"><b>ໝວດສິນຄ້າຍ່ອຍ1 (PH2)</b></label>

                                    </div>
                                    <div class="col-sm-4">
                                        <label for="ph3"><b>ໝວດສິນຄ້າຍ່ອຍ2 (PH3)</b></label>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="ph4"><b>ປະເພດສິນຄ້າ (PH4)</b></label>

                                    </div>

                                    <div class="col-sm-4">
                                        <label for="ph5"><b>ຍີ່ຫໍ້ (PH5)</b></label>

                                    </div>
                                    <div class="col-sm-4">
                                        <label for="ph6"><b>ຮູບແບບ (PH6)</b></label>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label for="ph7"><b>ຂະໜາດ (PH7)</b></label>

                                    </div>

                                    <div class="col-sm-4">
                                        <label for="ph8"><b>ອອກແບບ (PH8)</b></label>


                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="start_purchase_wh"><b>ສາງສັ່ງຊື້ເລີ້ມຕົ້ນ</b></label>

                                    </div>

                                    <div class="col-sm-5">
                                        <label for="start_purchase_shelf"><b>ບ່ອນເກັບສາງສັ່ງຊື້ເລີ້ມຕົ້ນ</b></label>

                                    </div>
                                    <div class="col-sm-4">
                                        <label for="start_purchase_unit"><b>ຫົວໜ່ວຍສັ່ງຊື້ເລີ້ມຕົ້ນ</b></label>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label for="start_sale_wh"><b>ສາງຂາຍເລີ້ມຕົ້ນ</b></label>

                                    </div>
                                    <div class="col-sm-5">
                                        <label for="start_sale_shelf"><b>ບ່ອນເກັບສາງຂາຍເລີ້ມຕົ້ນ</b></label>

                                    </div>

                                    <div class="col-sm-4">
                                        <label for="start_sale_unit"><b>ຫົວໜ່ວຍຂາຍເລີ້ມຕົ້ນ</b></label>

                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-4">
                                <h5 class="text-primary">ຫົວໜ່ວຍ</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/purchasing/show_purchasing.blade.php ENDPATH**/ ?>