<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="bg-white border-b border-gray-200 lao-font">
                    <div class="m-3">
                        <h4 class="text-info text-center"><i class="fa fa-info-circle" aria-hidden="true"></i>
                            ຕິດຕໍ່ລູກຄ້າ
                        </h4>
                        <form action="" method="POST" id="form-call-back-customer">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="txt_track_id" value="<?php echo e($t_id); ?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <h5 class="text-drak"><i class="fa fa-user" aria-hidden="true"></i> ລູກຄ້າ
                                    </h5>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label for="">ລະຫັດ</label>
                                            <input type="text" class="form-control" value="<?php echo e($t_code); ?>"
                                                readonly name="txt_track_code"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ຊື່ລູກຄ້າ</label>
                                            <input type="text" class="form-control" value="<?php echo e($data->tr_name); ?>"
                                                readonly name="txt_cus_name"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ທີ່ຢູ່</label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e($data->tr_cus_address); ?>" readonly
                                                name="txt_cus_address"><br>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="">ເບິໂທ</label>
                                            <input type="text" class="form-control" value="<?php echo e($data->tr_tel); ?>"
                                                readonly name="txt_cus_tel"><br>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <h5 class="text-drak"><i class="fa fa-product-hunt" aria-hidden="true"></i>
                                        ສິນຄ້າ
                                        <button class="btn btn-sm btn-info" type="button"
                                            onclick="add_product_item()"><i class="fa fa-cart-plus"
                                                aria-hidden="true"></i></button> <button class="btn btn-sm btn-danger"
                                            type="button" onclick="remove_product_item()"><i class="fa fa-minus"
                                                aria-hidden="true"></i></button>
                                    </h5>
                                    <table class="table">
                                        <tr>
                                            <th>ລາຍການ</th>
                                            <th>ກຸ່ມສິນຄ້າ</th>
                                            <th>ໝວດສິນຄ້າ</th>
                                            <th>ຍີ່ຫໍ້</th>
                                            <th width="10%">ຂະໜາດ</th>
                                        </tr>
                                        <tbody id="product-table">
                                            <?php
                                                $all_qty_product = count($con_cus_product) - 1;
                                            ?>
                                            <?php $__currentLoopData = $con_cus_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><input type="text" class="form-control"
                                                            value="<?php echo e($product_item->product_purchased); ?>"
                                                            name="txt_product_purchased[]"></td>
                                                    <td>
                                                        <select name="cb_pro_group[]" class="form-control" required
                                                            onchange="load_product_category(this.value,<?php echo e($index); ?>)">
                                                            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($g_item->id == $product_item->prg_id): ?>
                                                                    <?php
                                                                        $selected = 'selected';
                                                                    ?>
                                                                <?php else: ?>
                                                                    <?php
                                                                        $selected = '';
                                                                    ?>
                                                                <?php endif; ?>
                                                                <option value="<?php echo e($g_item->id); ?>" <?php echo e($selected); ?>>
                                                                    <?php echo e($g_item->prg_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <select id="cb_pro_cate_<?php echo e($index); ?>"
                                                            name="cb_pro_cate[]" class="form-control" required>
                                                            <?php
                                                            $pg_id = $product_item->prg_id;
                                                            $cate = App\Models\ProductCategory::where('pg_id', $pg_id)->get();
                                                            ?>
                                                            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prc_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($prc_item->id == $data->prc_id): ?>
                                                                    <?php
                                                                        $selected = 'selected';
                                                                    ?>
                                                                <?php else: ?>
                                                                    <?php
                                                                        $selected = '';
                                                                    ?>
                                                                <?php endif; ?>
                                                                <option value="<?php echo e($prc_item->id); ?>"
                                                                    <?php echo e($selected); ?>>
                                                                    <?php echo e($prc_item->prc_name); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <select name="cb_brand[]" class="form-control" required>
                                                            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($b_item->id == $product_item->prb_id): ?>
                                                                    <?php
                                                                        $selected = 'selected';
                                                                    ?>
                                                                <?php else: ?>
                                                                    <?php
                                                                        $selected = '';
                                                                    ?>
                                                                <?php endif; ?>
                                                                <option value="<?php echo e($b_item->id); ?>"
                                                                    <?php echo e($selected); ?>>
                                                                    <?php echo e($b_item->brand_name); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control" name="txt_size[]"
                                                            placeholder="..."
                                                            value="<?php echo e($product_item->product_size); ?>" required>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-12" style="padding-right: 12%; padding-left: 10%">
                                    <hr>
                                    <button class="btn btn-danger" type="button" onclick="not_by_product()"><i
                                            class="fa fa-times" aria-hidden="true"></i>
                                        ບໍ່ຊື້</button>

                                    <button class="btn btn-info"><i class="fa fa-check" aria-hidden="true"></i>
                                        ຊື້</button>
                                </div>
                            </div>


                        </form>
                        <?php
                        echo '<script> var group = ' . json_encode($group) . '; </script>';
                        echo '<script>var category = ' . json_encode($cate) . '</script>';
                        echo '<script>var brand = ' . json_encode($brand) . '</script>';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    function remove_product_item() {
        var rowctr = document.getElementById("product-table").rows.length - 1;
        if (rowctr > 0) {
            document.getElementById("product-table").deleteRow(rowctr);
        }
    }

    function add_product_item() {
        //add product group
        var group_html = '';
        $.each(group, function(i, g_item) {
            group_html = group_html + '<option value="' + g_item.id + '">' + g_item.prg_name + '</option>';
        })
        //add product category
        var cate_html = '';
        $.each(category, function(i, c_item) {
            cate_html = cate_html + '<option value="' + c_item.id + '">' + c_item.prc_name + '</option>';
        })
        //add product category
        var b_html = '';
        $.each(brand, function(i, b_item) {
            b_html = b_html + '<option value="' + b_item.id + '">' + b_item.brand_name + '</option>';
        })
        var rowctr = document.getElementById("product-table").rows.length;
        var html = '<tr><td>' +
            '<input type="text" class="form-control" name="txt_product_purchased[]" placeholder="..." required>' +
            '</td>' +
            '<td>' +
            '<select name="cb_pro_group[]" class="form-control" required ' +
            'onchange="load_product_category(this.value, ' + rowctr + ')">' + group_html +
            '</select>' +
            '</td>' +
            '<td>' +
            '<select id="cb_pro_cate_' + rowctr + '" name="cb_pro_cate[]" class="form-control" required>' + cate_html +
            '</select>' +
            '</td>' +
            '<td>' +
            '<select name="cb_brand[]" class="form-control" required>' + b_html +
            '</select>' +
            '</td>' +
            '<td>' +
            '<input type="text" class="form-control" name="txt_size[]" placeholder="...">' +
            '</td></tr>';
        $('#product-table').append(html);
    }
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#form-call-back-customer').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: '<span class="lao-font">ຢືນຢັນ</span> ?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.blockUI({
                        message: ''
                    });
                    let track_id = $('#form-call-back-customer input[name="txt_track_id"]')
                        .val();
                    let track_code = $('#form-call-back-customer input[name="txt_track_code"]')
                        .val();
                    $.ajax({
                        url: "<?php echo e(route('save-contract-customer')); ?>",
                        type: "POST",
                        data: $(this).serialize(),
                        success: function(e) {
                            console.log(e);
                            if (e == 'success') {
                                window.location.href =
                                    "/customer-purchase?track_id=" + track_id +
                                    "&track_code=" + track_code;
                            }
                        }
                    });
                }
            })
        })
    });

    function load_product_category(id, key) {
        $.blockUI({
            message: ''
        });
        $.ajax({
            url: "<?php echo e(route('sell-load-product-category')); ?>",
            type: "POST",
            data: {
                'id': id
            },
            success: function(result) {
                $('#cb_pro_cate_' + key).html('');
                $.each(result, function(index, item) {
                    $('#cb_pro_cate_' + key).append('<option value="' + item.id + '">' + item
                        .prc_name +
                        '</option>');
                });
                $.unblockUI();
            }
        });
    }

    function not_by_product() {
        Swal.fire({
            title: '<span class="lao-font">ເຫດຜົນທີ່ບໍ່ຊື້</span>',
            input: 'text',
            inputAttributes: {
                autocapitalize: 'off'
            },
            showCancelButton: true,
            confirmButtonText: 'Save',
            showLoaderOnConfirm: true,
            preConfirm: (data) => {

                var note = data.replace(' ', '');
                if (note == '') {
                    Swal.fire({
                        icon: 'error',
                        title: '<span class="lao-font">ແຈ້ງເຕືອນ</span>',
                        html: '<span class="lao-font">ທ່ານຕ້ອງໃສ່ ເຫດຜົນກ່ອນ !!!</span>'
                    });
                } else {
                    $.blockUI({
                        message: ''
                    });
                    var formData = $('#form-call-back-customer').serializeArray();
                    formData.push({
                        name: "txt_nobuy_note",
                        value: note
                    });
                    $.ajax({
                        url: "<?php echo e(route('save-customer-cancel')); ?>",
                        type: "POST",
                        data: formData,
                        success: function(e) {
                            console.log(e);
                            $.unblockUI();
                            if (e == 'success') {
                                window.location.href =
                                    "<?php echo e(route('seller-track-show')); ?>";
                            }
                        }
                    });
                }
            }
        })

    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/sellers/call-customer-back.blade.php ENDPATH**/ ?>