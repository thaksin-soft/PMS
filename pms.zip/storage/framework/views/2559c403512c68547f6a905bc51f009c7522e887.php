<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <ul class="nav side-menu">
            <li class="model-item"><a href="/"><i class="fa fa-home"></i> Dashboard</a></li>
            <li class="lao-font model-item"><a href="<?php echo e(route('con-no-contract-customer')); ?>"><i class="fa fa-flag"
                        aria-hidden="true"></i> ສະຫຼຸບການເຄື່ອນໄຫວ</a></li>
            <li class="lao-font model-item"><a href="<?php echo e(route('report-effective-contract')); ?>"><i class="fa fa-flag"
                        aria-hidden="true"></i> ຄ້າງຕິດຕໍ່ລູກຄ້າ</a></li>

            
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\crm\resources\views/layouts/marketing-sidebar.blade.php ENDPATH**/ ?>