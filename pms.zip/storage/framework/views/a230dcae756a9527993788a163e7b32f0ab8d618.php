<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4 class="text-info"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            ລາຍການລູກຄ້າຊື້
                        </h4>
                        <div class="row">
                            <div class="col-sm-2">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">ເດືອນ</span>
                                    </div>
                                    <input type="number" class="form-control" aria-label="month"
                                        value="<?php echo e($set_month); ?>" onchange="load_report_bymonth()" id="search-month">
                                </div>
                            </div>

                            <div class="col-sm-2">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">ປີ</span>
                                    </div>
                                    <input type="number" class="form-control" aria-label="year"
                                        value="<?php echo e($set_year); ?>" onchange="load_report_bymonth()" id="search-year">
                                </div>
                            </div>
                        </div>
                        <table class="table table-bordered">
                            <tr>
                                <th>ຊື່ລູກຄ້າ</th>
                                <th>ຊື່ສິນຄ້າ</th>
                                <th>ສິນຄ້າໝວດ</th>
                                <th>ສິນຄ້າປະເພດ</th>
                                <th>ວັນທີ່ປິດຂາຍ</th>
                                <th></th>
                            </tr>
                            <tbody class="text-primary">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->cus_name); ?></td>
                                        <td><?php echo e($item->product_buy); ?></td>
                                        <td><?php echo e($item->prg_name); ?></td>
                                        <td><?php echo e($item->prc_name); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><a href="" class="text-info"><i class="fa fa-eye"
                                                    aria-hidden="true"></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <span><?php echo e($data->links('vendor.pagination.custom')); ?></span>





                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    });

    function load_report_bymonth() {
        $.blockUI({
            message: ''
        });
        var month = $("#search-month").val();
        var year = $("#search-year").val();
        $.ajax({
            url: "<?php echo e(route('session-set-seller-report-purchased')); ?>",
            type: "GET",
            data: {
                'm': month,
                'y': year
            },
            success: function(e) {
                console.log(e);
                if (e == 'success') {
                    location.reload();
                }
            }
        })
    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/sellers/reports/report-cus-purchased.blade.php ENDPATH**/ ?>