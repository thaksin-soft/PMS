<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        #product-item {
            border: 1px solid;
        }

    </style>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <h3 class="text-info"><i class="fa fa-commenting" aria-hidden="true"></i>
                        ບັນທຶກການຕິດຕໍ່ຊື້ສິນຄ້າ
                        ຂອງລູກຄ້າ</h3>
                    <hr>
                    <form action="<?php echo e(route('track-online.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4 p-4" style="background: #c9c9c9!important">
                            <h5 class="text-primary"><u><i class="fa fa-users" aria-hidden="true"></i>
                                    ຂໍ້ມູນລູກຄ້າ</u>
                            </h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="txt_cus_name"><span class="text-danger">*</span>
                                            <b>ຊື່ລູກຄ້າ</b></label>
                                        <input type="text" class="form-control" id="txt_cus_name" name="txt_cus_name"
                                            aria-describedby="" placeholder="..." required>

                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="cb_gender"><span class="text-danger">*</span>
                                            <b>ເພດ</b></label>
                                        <select name="cb_gender" id="cb_gender" class="form-control">
                                            <option value="ຊາຍ">ຊາຍ</option>
                                            <option value="ຍິງ">ຍິງ</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="txt_cus_address"> <b>ທີ່ຢູ່</b></label>
                                        <input type="text" class="form-control" id="txt_cus_address"
                                            name="txt_cus_address" aria-describedby="" placeholder="...">

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="txt_tel"><span class="text-danger">*</span> <b>ເບິໂທ</b></label>
                                        <input type="number" class="form-control" id="txt_tel" name="txt_tel"
                                            aria-describedby="" placeholder="..." required>

                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="cb_contract_option"><span class="text-danger">*</span>
                                            <b>ຊ່ອງທາງການຕິດຕໍ່</b></label>
                                        <select name="cb_contract_option" id="cb_contract_option" class="form-control"
                                            required>
                                            <option value="facebook">Facebook</option>
                                            <option value="whatsapp">What's App</option>
                                            <option value="ໜ້າຮ້ານ">ໜ້າຮ້ານ</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label for="cb_contract_from"><span class="text-danger">*</span> <b>ຈາກ
                                                (ຊື່ຊ່ອງທາງລູກຄ້າຕິດຕໍ່)</b></label>
                                        <select name="cb_contract_from" id="cb_contract_from" class="form-control"
                                            required>
                                            <option value="Odienmall ໂອດ່ຽນມໍ">Odienmall ໂອດ່ຽນມໍ</option>
                                            <option value="Odienmall Pakse ໂອດ່ຽນມໍ ປາກເຊ">Odienmall Pakse ໂອດ່ຽນມໍ
                                                ປາກເຊ
                                            </option>
                                            <option value="ຂາຍສົ່ງແອທົ່ວລາວ">ຂາຍສົ່ງແອທົ່ວລາວ</option>
                                            <option value="OD Shop">OD Shop</option>
                                            <option value="Midea Lao">Midea Lao</option>
                                            <option value="Odien Air Conditioning">Odien Air Conditioning</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="txt_cus_facebook"><span class="text-danger">*</span>
                                            <b>ຊື່ແຟສລູກຄ້າ
                                                ຫຼື
                                                ເບີ
                                                whatsapp
                                            </b></label>
                                        <input type="text" class="form-control" id="txt_cus_facebook"
                                            name="txt_cus_facebook" aria-describedby="" placeholder="..." required>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <input type="file" id="upload_file" name="upload_file[]"
                                                onchange="preview_image();" multiple accept="image/*" required />

                                        </div>
                                        <div class="col-sm-6">
                                            <button type="button" class="btn btn-danger btn-sm"
                                                onclick="clear_image()"><i class="fa fa-times-circle"
                                                    aria-hidden="true"></i> clear ຮູບ</button>
                                        </div>
                                    </div>


                                    <div id="image_preview"
                                        class=""></div>

                                </div>

                            </div>
                        </div>

                        <div class="
                                        mb-4 p-4" style="background: #c9c9c9!important">
                                        <h5 class="text-primary"><u><i class="fa fa-product-hunt"
                                                    aria-hidden="true"></i>
                                                ຂໍ້ມູນສິນຄ້າ</u> <button class="btn btn-sm btn-info" type="button"
                                                onclick="add_product_item()"><i class="fa fa-cart-plus"
                                                    aria-hidden="true"></i></button> <button
                                                class="btn btn-sm btn-danger" type="button"
                                                onclick="remove_product_item()"><i class="fa fa-minus"
                                                    aria-hidden="true"></i></button>

                                        </h5>
                                        <div class="row">
                                            <?php
                                                $checked = 'checked';
                                            ?>
                                            <?php $__currentLoopData = $depend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depend_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-sm-2">
                                                    <label class="rd-container"><?php echo e($depend_item->depend_name); ?>

                                                        <input type="radio" <?php echo e($checked); ?> name="depend"
                                                            value="<?php echo e($depend_item->id); ?>"
                                                            onchange="load_employee(this.value)">
                                                        <span class="rd-checkmark"></span>
                                                    </label>
                                                </div>
                                                <?php
                                                    
                                                    $checked = '';
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </div>
                                        <div class="row">

                                            <div class="col-md-12">
                                                <div id="product-items" class="p-3"
                                                    style="background: #eeeded!important">

                                                    <table id="product-table" style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <div id="product-item" class="p-2">
                                                                    <div class="row">
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                                <label for="">
                                                                                    <b>ສິນຄ້າທີ່ລູກຄ້າສົນໃຈ</b></label>
                                                                                <input type="text"
                                                                                    class="form-control"
                                                                                    id="txt_pro_cus_interest"
                                                                                    name="txt_pro_cus_interest[]"
                                                                                    placeholder="..." required>

                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                                <label for="cb_pro_group">
                                                                                    <b>ສິນຄ້າ</b></label>
                                                                                <select id="cb_pro_group"
                                                                                    name="cb_pro_group[]"
                                                                                    class="form-control" required
                                                                                    onchange="load_product_category(this.value, 0)">
                                                                                    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            value="<?php echo e($g_item->id); ?>">
                                                                                            <?php echo e($g_item->prg_name); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                                <label for="cb_pro_cate">
                                                                                    <b>ຮູບແບບສິນຄ້າ</b></label>
                                                                                <select id="cb_pro_cate_0"
                                                                                    name="cb_pro_cate[]"
                                                                                    class="form-control" required>

                                                                                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prc_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            value="<?php echo e($prc_item->id); ?>">
                                                                                            <?php echo e($prc_item->prc_name); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <label for="cb_brand">
                                                                                    <b>ຍີ່ຫໍ້</b></label>
                                                                                <select name="cb_brand[]" id="cb_brand"
                                                                                    class="form-control" required>
                                                                                    <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            value="<?php echo e($b_item->id); ?>">
                                                                                            <?php echo e($b_item->brand_name); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                </select>

                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-1">
                                                                            <div class="form-group">
                                                                                <label for="txt_size">
                                                                                    <b>ຂະໜາດ</b></label>
                                                                                <input type="text"
                                                                                    class="form-control" id="txt_size"
                                                                                    name="txt_size[]"
                                                                                    aria-describedby=""
                                                                                    placeholder="...">

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </table>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <h6 for="txt_note" class="text-danger"> <b>ໝາຍເຫດ</b></h6>
                                                    <textarea name="txt_note" id="txt_note" class="form-control"
                                                        rows="5"></textarea>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="mb-3 p-4" style="background: #c9c9c9!important">
                                        <h5 class="text-primary"><u><i class="fa fa-male" aria-hidden="true"></i>
                                                ພະນັກງານຕິດຕໍ່ຫາລູກຄ້າ</u></h5>
                                        <div class="row" id="employee-section">
                                            <?php $checked = 'checked'; ?>
                                            <?php $__currentLoopData = $emp_seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-3">
                                                    <label class="rd-container"><a href="#" data-toggle="modal"
                                                            data-target="#modal-show-seller-track-list"><?php echo e($emp_item->emp_name); ?></a>
                                                        <input type="radio" <?php echo e($checked); ?> name="rd_employee"
                                                            value="<?php echo e($emp_item->id); ?>">
                                                        <span class="rd-checkmark"></span>
                                                    </label>
                                                </div>
                                                <?php $checked = ''; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>


                                    <hr>

                                    <button type="submit" class="btn btn-primary"><i class="fa fa-floppy-o"
                                            aria-hidden="true"></i>
                                        ບັນທືກ</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
    echo '<script> var group = ' . json_encode($group) . '; </script>';
    echo '<script>var category = ' . json_encode($cate) . '</script>';
    echo '<script>var brand = ' . json_encode($brand) . '</script>';
    ?>

    <!-- The Modal -->
    <div class="modal" id="modal-show-seller-track-list">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Modal Heading</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    Modal body..
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>



<script>
    function load_employee(depend_id) {
        $.ajax({
            url: "<?php echo e(route('jq-load-employee')); ?>",
            type: 'GET',
            data: {
                'id': depend_id
            },
            success: function(e) {
                $("#employee-section").html('');
                var checked = 'checked';
                $.each(e, function(index, item) {
                    $("#employee-section").append('<div class="col-md-3">' +
                        '<label class="rd-container"><a href="#" data-toggle="modal"' +
                        'data-target="#modal-show-seller-track-list">' + item.emp_name +
                        ' </a>' +
                        '<input type="radio" ' + checked + ' name="rd_employee"' +
                        'value="' + item.id + '">' +
                        '<span class="rd-checkmark"></span>' +
                        '</label>' +
                        '</div>');
                    checked = '';
                })
            }
        })
    }

    function remove_product_item() {
        var rowctr = document.getElementById("product-table").rows.length - 1;
        if (rowctr > 0) {
            document.getElementById("product-table").deleteRow(rowctr);
        }
    }

    function add_product_item() {
        //add product group
        var group_html = '';
        $.each(group, function(i, g_item) {
            group_html = group_html + '<option value="' + g_item.id + '">' + g_item.prg_name + '</option>';
        })
        //add product category
        var cate_html = '';
        $.each(category, function(i, c_item) {
            cate_html = cate_html + '<option value="' + c_item.id + '">' + c_item.prc_name + '</option>';
        })
        //add product category
        var b_html = '';
        $.each(brand, function(i, b_item) {
            b_html = b_html + '<option value="' + b_item.id + '">' + b_item.brand_name + '</option>';
        })
        var rowctr = document.getElementById("product-table").rows.length;
        var html = '<tr><td><div id="product-item" class="p-2">' +
            '<div class="row">' +
            '<div class="col-md-3">' +
            '<div class="form-group">' +
            '<label> <b>ສິນຄ້າທີ່ລູກຄ້າສົນໃຈ</b></label>' +
            '<input type="text" class="form-control" id="txt_pro_cus_interest" name="txt_pro_cus_interest[]" placeholder="..." required>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-3">' +
            '<div class="form-group">' +
            '<label for="cb_pro_group"> <b>ສິນຄ້າ</b></label>' +
            '<select id="cb_pro_group" name="cb_pro_group[]" class="form-control" required ' +
            'onchange="load_product_category(this.value, ' + rowctr + ')">' + group_html +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-3">' +
            '<div class="form-group">' +
            '<label for="cb_pro_cate"> <b>ຮູບແບບສິນຄ້າ</b></label>' +
            '<select id="cb_pro_cate_' + rowctr + '" name="cb_pro_cate[]" class="form-control" required>' + cate_html +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-2">' +
            '<div class="form-group">' +
            '<label for="cb_brand"> <b>ຍີ່ຫໍ້</b></label>' +
            '<select name="cb_brand[]" id="cb_brand" class="form-control" required>' + b_html +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-1">' +
            '<div class="form-group">' +
            '<label for="txt_size"> <b>ຂະໜາດ</b></label>' +
            '<input type="text" class="form-control" id="txt_size" name="txt_size[]" placeholder="...">' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div></td></tr>';
        $('#product-table').append(html);
    }
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    function load_product_category(id, i) {
        $.blockUI({
            message: ''
        });
        $.ajax({
            url: "<?php echo e(route('admin-load-product-category')); ?>",
            type: "GET",
            data: {
                'id': id
            },
            success: function(e) {
                $.unblockUI();
                $('#cb_pro_cate_' + i).html('');
                $.each(e, function(index, item) {
                    $('#cb_pro_cate_' + i).append('<option value="' + item.id + '">' + item
                        .prc_name +
                        '</option>');
                });
            }
        });
    }

    function clear_image() {
        $('#image_preview').html('');
        $('#upload_file').val('');
    }

    function preview_image() {
        $('#image_preview').html('');
        var total_file = document.getElementById("upload_file").files.length;
        for (var i = 0; i < total_file; i++) {
            $('#image_preview').append("<img src='" + URL.createObjectURL(event.target.files[i]) +
                "' width='200' height='200' class='m-2'>");
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/track-online/create.blade.php ENDPATH**/ ?>