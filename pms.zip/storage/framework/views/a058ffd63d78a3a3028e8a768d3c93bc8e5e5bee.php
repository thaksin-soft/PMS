<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- The Modal -->
    <div class="modal" id="modal-add-from-base">
        <div class="modal-dialog">
            <div class="modal-content lao-font">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="tab">
                        <button class="tablinks active" onclick="load_emp_from_base(event, 'odien')">Odien</button>
                        <button class="tablinks" onclick="load_emp_from_base(event, 'p&p')">P&P</button>
                    </div>

                    <div id="odien" class="tabcontent" style="display: block">
                        <h3>Odien</h3>
                        <table class="table">
                            <tr>
                                <th>ລຳດັບ</th>
                                <th>Code</th>
                                <th>ຊື່ພະນັກງານ</th>
                            </tr>
                            <tbody id="fb-odien-table">

                            </tbody>
                        </table>
                    </div>

                    <div id="p&p" class="tabcontent">
                        <h3>P&P</h3>
                        <table class="table">
                            <tr>
                                <th>ລຳດັບ</th>
                                <th>Code</th>
                                <th>ຊື່ພະນັກງານ</th>
                            </tr>
                            <tbody id="fb-pp-table"></tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">

                        <h4 class="text-info"><i class="fa fa-users" aria-hidden="true"></i> ແກ້ໄຂຂໍ້ມູນພະນັກງານ
                        </h4>
                        <form method="POST" action="<?php echo e(route('employee.update', $data[0]->emp_id)); ?>" id="form-emp">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-sm-5">

                                    
                                    <label for="
                                        from_base"><span class="text-danger">*</span> ຂໍ້ມູນພະນັກງານຈາກ
                                        SML</label>
                                    <input type="text" class="form-control text-center" id="emp_fb_name"
                                        name="emp_fb_name" readonly value="<?php echo e($data[0]->emp_name_fb); ?>">
                                    <div class="input-group mb-3">
                                        <input type="text" name="emp_fb_code" id="emp_fb_code" class="text-center"
                                            required readonly style="border: aquamarine 1px solid"
                                            value="<?php echo e($data[0]->code_fb); ?>">
                                        <input type="text" name="from_base" id="from_base"
                                            class="text-center form-control" required readonly
                                            style="border: aquamarine 1px solid" value="<?php echo e($data[0]->from_base); ?>">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text p-0">
                                                <button class="btn btn-primary m-0" type="button"
                                                    data-target="#modal-add-from-base" data-toggle="modal"><i
                                                        class="fa fa-search" aria-hidden="true"></i></button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <!-- full Name -->
                                    <div>
                                        <label for="emp_name"><span class="text-danger">*</span> ຊື່</label>

                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'emp_name','class' => 'form-control','type' => 'text','name' => 'emp_name','value' => ''.e($data[0]->emp_name).'','required' => true,'autofocus' => true,'placeholder' => 'ຊື່...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'emp_name','class' => 'form-control','type' => 'text','name' => 'emp_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(''.e($data[0]->emp_name).''),'required' => true,'autofocus' => true,'placeholder' => 'ຊື່...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div>
                                        <label for="emp_lname"><span class="text-danger">*</span> ນາມສະກຸນ</label>

                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'emp_lname','class' => 'form-control','type' => 'text','name' => 'emp_lname','value' => ''.e($data[0]->emp_lname).'','required' => true,'autofocus' => true,'placeholder' => 'ນາມສະກຸນ...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'emp_lname','class' => 'form-control','type' => 'text','name' => 'emp_lname','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(''.e($data[0]->emp_lname).''),'required' => true,'autofocus' => true,'placeholder' => 'ນາມສະກຸນ...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div>
                                        <label for="gender"><span class="text-danger">*</span> ເພດ</label>

                                        <select name="gender" id="gender" class="form-control" required>
                                            <?php if($data[0]->emp_gender == 'ຊາຍ'): ?>
                                                <option value="ຊາຍ" selected>ຊາຍ</option>
                                                <option value="ຍິງ">ຍິງ</option>
                                            <?php else: ?>
                                                <option value="ຊາຍ">ຊາຍ</option>
                                                <option value="ຍິງ" selected>ຍິງ</option>
                                            <?php endif; ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div>
                                        <label for="depend"><span class="text-danger">*</span> ສັງກັດ</label>

                                        <select name="depend" id="depend" class="form-control" required>
                                            <?php $__currentLoopData = $depend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data[0]->depend_id == $item->id): ?>
                                                    <option value="<?php echo e($item->id); ?>" selected>
                                                        <?php echo e($item->depend_name); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->depend_name); ?>

                                                    </option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <!-- User Role -->
                                    <div>
                                        <label for="password_confirmation"><span class="text-danger">*</span>
                                            ຕຳແໜ່ງ</label>
                                        <select name="user_role" id="user_role" class="form-control" required>
                                            <option value="">...</option>
                                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data[0]->role_name == $item->display_name): ?>
                                                    <option value="<?php echo e($item->name); ?>" selected>
                                                        <?php echo e($item->display_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($item->name); ?>">
                                                        <?php echo e($item->display_name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <!-- tel -->
                                    <div>
                                        <label for="tel"><span class="text-danger">*</span> ເບິໂທ</label>

                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'tel','class' => 'form-control','type' => 'text','name' => 'tel','value' => ''.e($data[0]->tel).'','required' => true,'autofocus' => true,'placeholder' => 'ເບິໂທຂອງພະນັກງານ...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'tel','class' => 'form-control','type' => 'text','name' => 'tel','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(''.e($data[0]->tel).''),'required' => true,'autofocus' => true,'placeholder' => 'ເບິໂທຂອງພະນັກງານ...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <hr>


                            <div class="flex items-center justify-end mt-4">


                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn btn-success']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-success']); ?><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                    <?php echo e(__(' ບັນທຶກ')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </div>
                        </form>




                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    load_fb_pp();

    function load_fb_pp() {
        $.ajax({
            type: "GET",
            url: "<?php echo e(Route('fetch-emp-fb-pp')); ?>",
            success: function(e) {
                //console.log(e);
                $("#fb-pp-table").html('');
                $.each(e, function(i, item) {
                    $("#fb-pp-table").append(`<tr>
            <td><button class="btn btn-sm btn-outline-success" 
            data-dismiss="modal" onclick="get_emp_fb('${item.code}','${item.name_1}','p&p')">
            <i class="fa fa-check-circle-o" aria-hidden="true">
            </i></button></td>
            <td>${item.code}</td>
            <td>${item.name_1}</td></tr>`);
                })
            }
        })

    }
    load_fb_odien();

    function load_fb_odien() {
        $.ajax({
            type: "GET",
            url: "<?php echo e(Route('fetch-emp-fb-odien')); ?>",
            success: function(e) {
                //console.log(e);
                $("#fb-odien-table").html('');
                $.each(e, function(i, item) {
                    $("#fb-odien-table").append(`<tr>
                <td><button class="btn btn-sm btn-outline-success" 
                data-dismiss="modal" onclick="get_emp_fb('${item.code}','${item.name_1}','odien')">
                <i class="fa fa-check-circle-o" aria-hidden="true">
                </i></button></td>
                <td>${item.code}</td>
                <td>${item.name_1}</td></tr>`);
                })
            }
        })

    }

    function get_emp_fb(code, name, base) {
        $("#form-emp input[name='from_base']").val(base);
        $("#form-emp input[name='emp_fb_code']").val(code);
        $("#form-emp input[name='emp_fb_name']").val(name);
    }

    function load_emp_from_base(evt, fbName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(fbName).style.display = "block";
        evt.currentTarget.className += " active";

    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/employees/edit.blade.php ENDPATH**/ ?>