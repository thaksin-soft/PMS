{{-- <li class="model-item"><a href="/"><i class="fa fa-product-hunt" aria-hidden="true"></i> ສ້າງສິນຄ້າໃໝ່</a>
</li> --}}
{{-- <li class="lao-font model-item"><a><i class="fa fa-edit"></i> ຈັດການຂໍ້ມູນ <span
            class="fa fa-chevron-down"></span></a>
    <ul class="nav child_menu">
        <li class="model-item"><a href="{{ route('pro-group.index') }}">ກຸ່ມສິນຄ້າ</a></li>
        <li class="model-item"><a href="{{ route('pro-category.index') }}">ໝວດສິນຄ້າ</a></li>
        <li class="model-item"><a href="{{ route('pro-brands.index') }}">ຍີ່ຫໍ່ສິນຄ້າ</a></li>
    </ul>
</li> --}}

{{-- <li class="lao-font model-item"><a><i class="fa fa-edit"></i> ລາຍການ<span
            class="fa fa-chevron-down"></span></a>
    <ul class="nav child_menu">
        <li class="model-item"><a href="#">ລາຍການ</a></li>
    </ul>
</li> --}}
